# Diamond Pricing: Exploratory Data Analysis

Project from the **Google Advanced Data Analytics Professional Certificate** — applying the six-phase EDA framework (Discover → Structure → Clean → Join → Validate → Present) to a real dataset of 53,940 diamonds.

## Key finding

Diamonds with the *best* clarity grade (IF) average a **lower** price than diamonds with the *worst* clarity grade (I1) — $2,871 vs $3,927. That looks backwards until you check carat: buyers of flawless stones are choosing much smaller diamonds on average (0.51 vs 1.28 carat). Carat is confounding the clarity-price relationship — a reminder that a single correlation can mislead without checking for a confounding variable underneath it.

![Correlation heatmap](images/fig4_correlation_heatmap.png)

## Repository structure

```
├── notebooks/
│   └── diamond_pricing_eda.ipynb   # Full analysis: code, charts, and narrative, in order
├── data/
│   ├── diamonds_raw.csv            # Original, unmodified dataset (53,940 rows)
│   └── diamonds_clean.csv          # After removing invalid/duplicate rows (53,772 rows)
├── images/
│   └── *.png                       # Exported chart images, referenced in this README
└── README.md
```

## What's inside the notebook

1. **Discover** — states the hypothesis (carat drives price) and the questions being asked before touching the data
2. **Structure** — inspects shape, types, and column meanings
3. **Clean** — finds and removes 168 rows with impossible measurements or exact duplicates
4. **Join** — not needed here (single-table dataset) — noted explicitly rather than skipped
5. **Validate** — sanity-checks the cleaned data against physical logic (carat vs. volume correlation)
6. **Present** — answers the original questions with charts and a written narrative, including the confounding-variable finding above

## Tools

Python · pandas · seaborn · matplotlib · Jupyter

## Data quality issues found and handled

- 20 rows with physically impossible 0mm measurements
- 2 rows with measurements ~30mm (likely decimal-point entry errors)
- 146 exact duplicate rows

## Next step

A multiple regression (carat + cut + clarity + color together) to isolate each variable's true independent effect — covered later in the certificate.

## Source

Dataset: [seaborn-data / diamonds.csv](https://github.com/mwaskom/seaborn-data)
